import { AceDataCloud } from '@acedatacloud/sdk';
import { Keypair } from '@solana/web3.js';
import { walletAdapter } from '../utils/solana';
import { logger } from '../utils/logger';
import { withRetry } from '../utils/retry';
import type {
  NewsItem,
  NewsSearchResult,
  LLMAnalysisResult,
  MarketNarrative,
  InsightsResult,
  GeneratedImage,
} from '../types/index';

let _aceClient: AceDataCloud | null = null;

// x402-client is ESM-only — loaded via dynamic import once at startup
let _x402Handler: unknown = null;

async function getX402Handler(keypair: Keypair): Promise<unknown> {
  if (_x402Handler) return _x402Handler;

  // Dynamic import for ESM-only @acedatacloud/x402-client
  const x402Module = await import('@acedatacloud/x402-client/sdk');
  const createX402PaymentHandler =
    (x402Module as { createX402PaymentHandler: (opts: unknown) => unknown })
      .createX402PaymentHandler;

  const adapter = walletAdapter(keypair);
  _x402Handler = createX402PaymentHandler({
    network: 'solana',
    solanaWallet: adapter,
    facilitatorUrl:
      process.env.ACE_PAYMENT_FACILITATOR || 'https://facilitator.acedata.cloud',
  });

  return _x402Handler;
}

export async function createAceClient(keypair: Keypair): Promise<AceDataCloud> {
  if (_aceClient) return _aceClient;

  const paymentHandler = await getX402Handler(keypair);

  _aceClient = new AceDataCloud({
    paymentHandler: paymentHandler as Parameters<typeof AceDataCloud>[0]['paymentHandler'],
    baseURL: process.env.ACE_BASE_URL || 'https://api.acedata.cloud',
  });

  logger.debug('Ace Data Cloud client initialised with x402 USDC payment handler');
  return _aceClient;
}

// ─── Service 1: Web Search ────────────────────────────────────────────────────

export async function searchCryptoNews(
  aceClient: AceDataCloud,
  assets: string[]
): Promise<NewsSearchResult> {
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const queries = [
    `Bitcoin BTC price today ${today} market update`,
    `Ethereum ETH price ${today} crypto news`,
    `${assets.slice(0,3).join(' ')} crypto price today ${today}`,
    `${assets[0]} ${assets[1]} market analysis ${new Date().toLocaleString('en-US', {month:'long', year:'numeric'})}`,
    `crypto market news ${today} latest`,
    `Solana SOL BNB AVAX price update ${today}`,
  ];

  const allItems: NewsItem[] = [];
  const seenUrls = new Set<string>();

  for (const query of queries) {
    try {
      // Correct Ace SDK call: aceClient.search.google({ query, type: 'search' })
      const result = await withRetry(
        () => aceClient.search.google({ query, type: 'search', page: 1 }),
        { maxAttempts: 3, initialDelayMs: 2000 },
        `ace-search: ${query.slice(0, 40)}`
      );

      // Ace search returns { results: [...] } or { organic: [...] }
      const rawResult = result as Record<string, unknown>;
      const items = (
        (rawResult.organic as unknown[]) ||
        (rawResult.results as unknown[]) ||
        []
      ) as Array<{
        title?: string;
        url?: string;
        link?: string;
        snippet?: string;
        description?: string;
        source?: string;
        date?: string;
      }>;

      for (const item of items) {
        const url = item.url || item.link || '';
        if (!url || seenUrls.has(url)) continue;
        seenUrls.add(url);

        const title = item.title || '';
        const snippet = item.snippet || item.description || '';
        const upperText = `${title} ${snippet}`.toUpperCase();
        const relevanceScore = assets.reduce(
          (score, asset) => score + (upperText.includes(asset) ? 1 : 0),
          0
        );

        allItems.push({
          title,
          url,
          snippet,
          source: item.source || (() => { try { return new URL(url).hostname; } catch { return url; } })(),
          publishedAt: item.date || new Date().toISOString(),
          relevanceScore,
        });
      }

      logger.debug(
        `Search "${query.slice(0, 40)}..." → ${items.length} results`
      );
    } catch (err) {
      logger.warn(
        `Search query failed: ${err instanceof Error ? err.message : String(err)}`
      );
    }
  }

  const sorted = allItems.sort((a, b) => b.relevanceScore - a.relevanceScore);
  const top25 = sorted.slice(0, 25);

  logger.info(
    `Ace Web Search complete: ${allItems.length} total → ${top25.length} kept`
  );

  return { items: top25, totalResults: allItems.length, query: queries[0] };
}

// ─── Service 2: LLM Analysis (3 separate GPT-4o calls) ───────────────────────

export async function generateAnalysis(
  aceClient: AceDataCloud,
  newsItems: NewsItem[],
  assets: string[]
): Promise<{ analysis: LLMAnalysisResult; narrative: MarketNarrative; insights: InsightsResult }> {
  const newsContext = newsItems
    .slice(0, 20)
    .map((n, i) => `${i + 1}. ${n.title}\n   Source: ${n.source}\n   ${n.snippet}`)
    .join('\n\n');

  const dateStr = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // ── LLM Call 1: Structured analysis ──────────────────────────────────────
  logger.info('Ace LLM: Generating structured news analysis...');
  const analysisResponse = await withRetry(
    () =>
      aceClient.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content:
              'You are a professional crypto market analyst. Always respond with valid JSON only — no markdown, no prose outside JSON.',
          },
          {
            role: 'user',
            content: `You are analyzing LIVE crypto news from ${dateStr}. Use ONLY the information in the news items below — do NOT use your training data for prices or market conditions. Today is ${dateStr}.

Return a JSON object with this exact structure:
{
  "sentiment": "bullish" | "bearish" | "neutral",
  "sentimentScore": number between -1.0 and 1.0,
  "keyThemes": [string, string, string],
  "topStories": [{"headline": string, "impact": string}],
  "assetSentiment": {"${assets.join('": "bullish|bearish|neutral", "')}" : "bullish|bearish|neutral"},
  "marketPhase": string
}

LIVE NEWS FROM TODAY (${dateStr}) — base your analysis ONLY on this:
${newsContext}`,
          },
        ],
        max_tokens: 1000,
      }),
    { maxAttempts: 3, initialDelayMs: 3000 },
    'ace-llm-analysis'
  );

  let analysis: LLMAnalysisResult;
  try {
    const rawText =
      (analysisResponse as { choices: Array<{ message: { content: string } }> })
        .choices[0]?.message?.content || '{}';
    const cleaned = rawText.replace(/```json|```/g, '').trim();
    analysis = JSON.parse(cleaned) as LLMAnalysisResult;
  } catch {
    logger.warn('Failed to parse LLM analysis JSON, using defaults');
    analysis = {
      sentiment: 'neutral',
      sentimentScore: 0,
      keyThemes: ['Market uncertainty', 'DeFi developments', 'Regulatory clarity'],
      topStories: newsItems.slice(0, 3).map((n) => ({
        headline: n.title,
        impact: 'Market impact being assessed',
      })),
      assetSentiment: Object.fromEntries(
        assets.map((a) => [a, 'neutral' as const])
      ),
      marketPhase: 'Consolidation',
    };
  }

  // ── LLM Call 2: Full market narrative ────────────────────────────────────
  logger.info('Ace LLM: Generating full market narrative...');
  const narrativeResponse = await withRetry(
    () =>
      aceClient.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content:
              'You are Nexus Intel, a premier autonomous crypto intelligence platform. Write professional, data-driven market reports.',
          },
          {
            role: 'user',
            content: `Write a comprehensive crypto market report for ${dateStr}.

Market sentiment: ${analysis.sentiment} (score: ${analysis.sentimentScore})
Key themes: ${analysis.keyThemes.join(', ')}
Tracked assets: ${assets.join(', ')}

Based on these ${newsItems.length} news items (showing top 15):
${newsItems
  .slice(0, 15)
  .map((n) => `• ${n.title} (${n.source})`)
  .join('\n')}

Write exactly 5 sections separated by "##":
## Market Overview
## Asset Analysis
## DeFi & Ecosystem Update
## Macro Context
## Forward Outlook

Total length: ~1500 words. Professional financial writing style.`,
          },
        ],
        max_tokens: 2000,
      }),
    { maxAttempts: 3, initialDelayMs: 3000 },
    'ace-llm-narrative'
  );

  const narrativeText =
    (narrativeResponse as { choices: Array<{ message: { content: string } }> })
      .choices[0]?.message?.content || 'Market analysis unavailable.';
  const sections = parseNarrativeSections(narrativeText);
  const wordCount = narrativeText.split(/\s+/).length;

  const narrative: MarketNarrative = {
    title: `Nexus Intel Market Report — ${dateStr}`,
    fullText: narrativeText,
    wordCount,
    sections,
  };

  // ── LLM Call 3: Insights extraction ──────────────────────────────────────
  logger.info('Ace LLM: Extracting key insights...');
  const insightsResponse = await withRetry(
    () =>
      aceClient.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content:
              'You are a crypto market strategist. Respond with valid JSON only — no markdown or text outside JSON.',
          },
          {
            role: 'user',
            content: `Based on today's market analysis (sentiment: ${analysis.sentiment}), extract actionable intelligence.

Return JSON:
{
  "keyInsights": ["insight1", "insight2", "insight3", "insight4", "insight5"],
  "riskFactors": ["risk1", "risk2", "risk3"],
  "opportunities": ["opportunity1", "opportunity2"],
  "oneLineOutlook": "One sentence market outlook"
}

Context: ${narrative.sections[0]?.content || narrativeText.slice(0, 500)}`,
          },
        ],
        max_tokens: 800,
      }),
    { maxAttempts: 3, initialDelayMs: 3000 },
    'ace-llm-insights'
  );

  let insights: InsightsResult;
  try {
    const rawText =
      (insightsResponse as { choices: Array<{ message: { content: string } }> })
        .choices[0]?.message?.content || '{}';
    const cleaned = rawText.replace(/```json|```/g, '').trim();
    insights = JSON.parse(cleaned) as InsightsResult;
  } catch {
    logger.warn('Failed to parse LLM insights JSON, using defaults');
    insights = {
      keyInsights: [
        'Monitor key support/resistance levels',
        'Watch for volume confirmation on breakouts',
        'DeFi TVL trends indicate market health',
        'Institutional flows remain a key indicator',
        'Regulatory developments require close monitoring',
      ],
      riskFactors: [
        'Macro uncertainty could dampen risk appetite',
        'Liquidity conditions remain tight in some sectors',
        'Regulatory risk in key jurisdictions',
      ],
      opportunities: [
        'Oversold conditions in quality assets present entry points',
        'DeFi yield opportunities remain attractive relative to TradFi',
      ],
      oneLineOutlook: `${analysis.sentiment.charAt(0).toUpperCase() + analysis.sentiment.slice(1)} bias with selective opportunities in ${assets.slice(0, 2).join(' and ')}.`,
    };
  }

  logger.info(
    `LLM analysis complete — sentiment: ${analysis.sentiment}, words: ${narrative.wordCount}`
  );

  return { analysis, narrative, insights };
}

function parseNarrativeSections(
  text: string
): Array<{ heading: string; content: string }> {
  const sections: Array<{ heading: string; content: string }> = [];
  const parts = text.split(/^## /m);
  for (const part of parts) {
    if (!part.trim()) continue;
    const lines = part.split('\n');
    const heading = lines[0]?.trim() || 'Section';
    const content = lines.slice(1).join('\n').trim();
    if (content) sections.push({ heading, content });
  }
  return sections;
}

// ─── Service 3: Image Generation ─────────────────────────────────────────────

export async function generateReportCover(
  aceClient: AceDataCloud,
  sentiment: 'bullish' | 'bearish' | 'neutral',
  assets: string[]
): Promise<GeneratedImage | null> {
  const sentimentColors = {
    bullish: 'vibrant emerald green and gold',
    bearish: 'deep crimson red and dark grey',
    neutral: 'electric blue and silver',
  };

  const prompt =
    `Professional crypto market intelligence report cover, dark cyberpunk aesthetic, ` +
    `${sentimentColors[sentiment]} color scheme, glowing data visualizations and charts, ` +
    `blockchain network nodes, ${assets.slice(0, 3).join(' ')} logos subtly incorporated, ` +
    `dramatic lighting, ultra high quality, 4K`;

  try {
    logger.info('Ace Image Generation: Creating report cover...');

    // Correct call: aceClient.images.generate({ prompt, provider, wait: true })
    // wait: true makes the SDK poll until the image is ready
    const result = await withRetry(
      () =>
        aceClient.images.generate({
          prompt,
          provider: 'nano-banana',
          wait: true,
          maxWait: 120000,
        }),
      { maxAttempts: 2, initialDelayMs: 5000 },
      'ace-image-gen'
    );

    const rawResult = result as Record<string, unknown>;
    const imageUrl = String(
      rawResult.url || rawResult.imageUrl || rawResult.image_url || rawResult.output || ''
    );

    if (!imageUrl) {
      logger.warn('Image generation returned no URL');
      return null;
    }

    // Download and base64-encode the image
    const axios = (await import('axios')).default;
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
    });
    const base64 = Buffer.from(response.data as ArrayBuffer).toString('base64');
    const contentType =
      (response.headers['content-type'] as string) || 'image/png';

    logger.info(
      `Image generated: ${imageUrl.slice(0, 60)}... (${base64.length} chars B64)`
    );

    return { url: imageUrl, base64, mimeType: contentType, provider: 'nano-banana', prompt };
  } catch (err) {
    logger.warn(
      `Image generation failed (non-fatal): ${err instanceof Error ? err.message : String(err)}`
    );
    return null;
  }
}
