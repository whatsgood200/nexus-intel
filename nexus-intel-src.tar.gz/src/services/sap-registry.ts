import { SapClient, Pdas } from '@oobe-protocol-labs/synapse-sap-sdk';
import { Keypair, PublicKey } from '@solana/web3.js';
import { logger } from '../utils/logger';
import { withRetry } from '../utils/retry';
import type { SAPDiscoveryResult } from '../types/index';

let _sapClient: SapClient | null = null;

export function createSAPClient(
  keypair: Keypair,
  rpcUrl: string,
  apiKey: string
): SapClient {
  if (_sapClient) return _sapClient;
  const fullRpcUrl = `${rpcUrl}?api_key=${apiKey}`;
  _sapClient = new SapClient({ rpcUrl: fullRpcUrl, wallet: keypair });
  logger.debug(`SAP client initialised on ${rpcUrl}`);
  return _sapClient;
}

export async function discoverSAPTools(client: SapClient): Promise<SAPDiscoveryResult> {
  logger.info('SAP: Starting tool discovery...');

  let networkOverview = { totalAgents: 0, activeAgents: 0, toolsCount: 0 };
  let aceAgents: SAPDiscoveryResult['aceAgents'] = [];
  let dataTools: SAPDiscoveryResult['dataTools'] = [];

  // ── Step 2a: Global registry stats ───────────────────────────────────────
  try {
    const [globalPda] = Pdas.getGlobalPDA();
    const globalAccount = await withRetry(
      () => client.agent.program.account.globalRegistry.fetch(globalPda),
      { maxAttempts: 3, initialDelayMs: 2000 },
      'sap-global-registry'
    ) as Record<string, unknown>;

    networkOverview.totalAgents = Number(globalAccount.totalAgents ?? globalAccount.agentCount ?? 0);
    networkOverview.toolsCount  = Number(globalAccount.totalTools  ?? globalAccount.toolCount  ?? 0);

    logger.info(
      `SAP Network — ${networkOverview.totalAgents} total agents, ${networkOverview.toolsCount} tools`
    );
  } catch (err) {
    logger.warn(`SAP global registry: ${err instanceof Error ? err.message : String(err)}`);
  }

  // ── Step 2b: Enumerate all agentAccount PDAs, filter by protocol ─────────
  try {
    const allAgents = await withRetry(
      () => client.agent.program.account.agentAccount.all(),
      { maxAttempts: 3, initialDelayMs: 2000 },
      'sap-all-agents'
    ) as Array<{ publicKey: PublicKey; account: Record<string, unknown> }>;

    networkOverview.totalAgents  = Math.max(networkOverview.totalAgents,  allAgents.length);
    networkOverview.activeAgents = allAgents.length;

    // Filter for agents that list 'ace-data' or 'ace' in their protocols array
    aceAgents = allAgents
      .filter((a) => {
        const protos = (a.account.protocols as string[] | undefined) ?? [];
        return protos.some((p) =>
          p.toLowerCase().includes('ace') || p.toLowerCase().includes('data')
        );
      })
      .slice(0, 20)
      .map((a) => ({
        name:         String(a.account.name    ?? a.account.agentId ?? 'Unknown'),
        address:      a.publicKey.toBase58(),
        protocol:     'ace-data',
        capabilities: ((a.account.capabilities as Array<{ id: string }>) ?? []).map((c) => c.id),
      }));

    logger.info(
      `SAP Discovery: ${allAgents.length} agents enumerated, ` +
        `${aceAgents.length} with ace-data protocol`
    );
  } catch (err) {
    logger.warn(`SAP agent enumeration: ${err instanceof Error ? err.message : String(err)}`);
  }

  // ── Step 2c: Enumerate toolDescriptor accounts ────────────────────────────
  try {
    const allTools = await withRetry(
      () => client.agent.program.account.toolDescriptor.all(),
      { maxAttempts: 3, initialDelayMs: 2000 },
      'sap-all-tools'
    ) as Array<{ account: Record<string, unknown> }>;

    networkOverview.toolsCount = Math.max(networkOverview.toolsCount, allTools.length);

    // Keep tools tagged data / search / ai
    dataTools = allTools
      .filter((t) => {
        const cat = String(t.account.category ?? t.account.tags ?? '').toLowerCase();
        return cat.includes('data') || cat.includes('search') || cat.includes('ai') || cat.includes('llm');
      })
      .slice(0, 20)
      .map((t) => ({
        name:        String(t.account.name        ?? t.account.toolId      ?? 'Unknown'),
        category:    String(t.account.category    ?? 'data'),
        description: String(t.account.description ?? ''),
      }));

    logger.info(
      `SAP Discovery: ${allTools.length} tools total, ` +
        `${dataTools.length} in data/AI/search category: ` +
        `${dataTools.slice(0, 4).map((t) => t.name).join(', ')}`
    );
  } catch (err) {
    logger.warn(`SAP tool enumeration: ${err instanceof Error ? err.message : String(err)}`);
  }

  return { networkOverview, aceAgents, dataTools, discoveredAt: new Date().toISOString() };
}
